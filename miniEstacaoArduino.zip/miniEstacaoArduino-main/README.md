# miniEstacaoArduino
Código para a mini estação meteorológica: https://www.canva.com/design/DAFxegLwi9U/4jast3xBgEmnFt4GChL1eQ/edit
Desenvolvido por Antônio Campos Neto, antoniocamposneto9@gmail.com
Graduando em Geografia, UFRN

Code for mini meteorological station:  https://www.canva.com/design/DAFxegLwi9U/4jast3xBgEmnFt4GChL1eQ/edit
Made by Antônio Campos Neto
Graduating in Geopraphy, Federal University of Rio Grande do Norte, Brazil.
